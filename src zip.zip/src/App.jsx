import React, { useState } from 'react';
import './Calculator.css'; // Importing CSS

function Calculator() {
  const [result, setResult] = useState(0);
  const [input, setInput] = useState('');

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const add = () => {
    setResult(result + parseFloat(input));
  };

  const subtract = () => {
    setResult(result - parseFloat(input));
  };

  const multiply = () => {
    setResult(result * parseFloat(input));
  };

  const divide = () => {
    if (input === '0') {
      alert('Cannot divide by zero');
    } else {
      setResult(result / parseFloat(input));
    }
  };

  const resetInput = () => {
    setInput('');
  };

  const resetResult = () => {
    setResult(0);
  };

  return (
    <div className="calculator-container">
      <h1>Simplest Working Calculator</h1>
      <div className="result-display">{result}</div>
      <input 
        type="number" 
        value={input} 
        onChange={handleInputChange} 
        className="input-box"
      />
      <div className="button-container">
        <button onClick={add}>add</button>
        <button onClick={subtract}>subtract</button>
        <button onClick={multiply}>multiply</button>
        <button onClick={divide}>divide</button>
        <button onClick={resetInput} className="reset-input-btn">reset input</button>
        <button onClick={resetResult} className="reset-result-btn">reset result</button>
      </div>
    </div>
  );
}

export default Calculator;
